console.log("==========================");
console.log("Starting Twitter Script...");
console.log("==========================");