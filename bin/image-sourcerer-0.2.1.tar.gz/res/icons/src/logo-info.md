This file is more for personal reference so that I don't lose track of things like fonts, colours, etc.\
Also, this is just in case anyone is wondering, I designed all art. I used inkscape and the vectors can be found in this directory. There should be *no copyright problems whatsoever*.

### Fonts:
- Z003 for the logo (came with inkscape by default)
  - I just found out this is actually called "Zapf Chancery Medium Italic"

### Colour Codes:
- #542538 for the title text and popup text
- #C30B38 for the title accents
- #C3809B for the popup background

That's it for now.
